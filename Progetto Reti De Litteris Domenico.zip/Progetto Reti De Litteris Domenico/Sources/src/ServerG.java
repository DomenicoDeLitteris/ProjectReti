import java.io.*;
import java.net.*;

class GreenPass implements Serializable {
    String tessera;
    long scadenza;
    int servizio;
}

public class ServerG {
    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.err.printf("usage: %s <IPaddress>\n", ServerG.class.getSimpleName());
            System.exit(1);
        }

        ServerSocket listenfd;
        Socket sockfd;
        ObjectOutputStream out;
        ObjectInputStream in;

        try {
            listenfd = new ServerSocket(1026);
        } catch (IOException e) {
            System.err.println("Error creating server socket");
            e.printStackTrace();
            return;
        }

        while (true) {
            try {
                sockfd = listenfd.accept();
                out = new ObjectOutputStream(sockfd.getOutputStream());
                in = new ObjectInputStream(sockfd.getInputStream());
            } catch (IOException e) {
                System.err.println("Error accepting connection or creating streams");
                e.printStackTrace();
                continue;
            }

            Thread clientThread = new Thread(() -> {
                GreenPass greenPass;
                try {
                    while ((greenPass = (GreenPass) in.readObject()) != null) {
                        greenPass.tessera = greenPass.tessera.substring(0, 20);
                        System.out.println("Tessera Sanitaria: " + greenPass.tessera);

                        Socket requestfd;
                        ObjectOutputStream requestOut;
                        ObjectInputStream requestIn;

                        try {
                            requestfd = new Socket(args[0], 1025);
                            requestOut = new ObjectOutputStream(requestfd.getOutputStream());
                            requestIn = new ObjectInputStream(requestfd.getInputStream());
                        } catch (IOException e) {
                            System.err.println("Error connecting to serverV or creating streams");
                            e.printStackTrace();
                            continue;
                        }

                        try {
                            requestOut.writeObject(greenPass);
                            requestOut.flush();
                            System.out.println("Richiesta Consegnata");
                            System.out.println("Servizio: " + greenPass.servizio);

                            if (greenPass.servizio == 0) {
                                Object response = requestIn.readObject();

                                if (response instanceof GreenPass) {
                                    GreenPass responseGreenPass = (GreenPass) response;
                                    System.out.println("Tessera Sanitaria: " + responseGreenPass.tessera);
                                    System.out.println("Scadenza: " + new java.util.Date(responseGreenPass.scadenza));

                                    out.writeObject(responseGreenPass);
                                    out.flush();
                                } else {
                                    System.out.println("Green Pass non trovato");
                                }
                            }

                            requestOut.close();
                            requestIn.close();
                            requestfd.close();
                        } catch (IOException | ClassNotFoundException e) {
                            System.err.println("Error reading or writing data to serverV");
                            e.printStackTrace();
                        }
                    }
                } catch (IOException | ClassNotFoundException e) {
                    System.err.println("Error reading data from the client");
                    e.printStackTrace();
                } finally {
                    try {
                        in.close();
                        out.close();
                        sockfd.close();
                    } catch (IOException e) {
                        System.err.println("Error closing client connection");
                        e.printStackTrace();
                    }
                }
            });

            clientThread.start();
        }
    }
}
