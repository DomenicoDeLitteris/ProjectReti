import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.SocketException;
import java.net.InetAddress;
import java.net.InetSocketAddress;

public class Wrapper {
    public static Socket Socket(int family, int type, int protocol) throws IOException {
        return new Socket();
    }

    public static void Connect(Socket sockfd, InetAddress addr, int port) throws IOException {
        try {
            sockfd.connect(new InetSocketAddress(addr, port));
        } catch (SocketException e) {
            System.err.println("connect error: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void Bind(ServerSocket sockfd, InetAddress addr, int port) throws IOException {
        try {
            sockfd.bind(new InetSocketAddress(addr, port));
        } catch (SocketException e) {
            System.err.println("bind error: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void Listen(ServerSocket sockfd, int queue_lenght) throws IOException {
        try {
            sockfd.setSoTimeout(0);
            sockfd.setReuseAddress(true);
            sockfd.setReceiveBufferSize(queue_lenght);
        } catch (SocketException e) {
            System.err.println("listen error: " + e.getMessage());
            System.exit(1);
        }
    }

    public static Socket Accept(ServerSocket sockfd) throws IOException {
        try {
            return sockfd.accept();
        } catch (SocketException e) {
            System.err.println("accept error: " + e.getMessage());
            System.exit(1);
            return null;
        }
    }
}
