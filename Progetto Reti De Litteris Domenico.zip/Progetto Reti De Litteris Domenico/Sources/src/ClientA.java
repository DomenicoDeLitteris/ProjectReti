import java.io.*;
import java.net.*;

public class ClientA {
    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.err.printf("usage: %s <IPaddress> <TesseraSanitaria>\n", ClientA.class.getSimpleName());
            System.exit(1);
        }

        if (args[1].length() != 20) {
            System.err.println("Tessera Sanitaria non valida");
            System.exit(1);
        }

        Socket sockfd;
        OutputStreamWriter out;

        try {
            sockfd = new Socket(args[0], 1024);
            out = new OutputStreamWriter(sockfd.getOutputStream());
        } catch (IOException e) {
            System.err.println("Error connecting to the server");
            e.printStackTrace();
            return;
        }

        try {
            out.write(args[1]);
            out.flush();
            System.out.println("Tessera Sanitaria consegnata");
        } catch (IOException e) {
            System.err.println("Error writing to the server");
            e.printStackTrace();
        } finally {
            out.close();
            sockfd.close();
        }
    }
}
