import java.io.*;
import java.net.*;

class GreenPass implements Serializable {
    String tessera;
    long scadenza;
    int servizio;
}

public class ClientT {
    public static void main(String[] args) throws IOException {
        if (args.length != 4) {
            System.err.printf("usage: %s <IPaddress> <TesseraSanitaria> <V or I>\n", ClientT.class.getSimpleName());
            System.exit(1);
        }

        if (args[1].length() != 20) {
            System.err.println("Tessera Sanitaria non valida");
            System.exit(1);
        }

        Socket sockfd;
        ObjectOutputStream out;

        try {
            sockfd = new Socket(args[0], 1026);
            out = new ObjectOutputStream(sockfd.getOutputStream());
        } catch (IOException e) {
            System.err.println("Error connecting to the server");
            e.printStackTrace();
            return;
        }

        GreenPass greenPass = new GreenPass();
        greenPass.tessera = args[1];

        if (args[2].equals("V")) {
            greenPass.servizio = 1;
        } else if (args[2].equals("I")) {
            greenPass.servizio = 2;
        } else {
            System.out.println(args[2] + " is not valid");
            System.exit(1);
        }

        try {
            out.writeObject(greenPass);
            out.flush();
            System.out.println("Richiesta inoltrata");
        } catch (IOException e) {
            System.err.println("Error writing to the server");
            e.printStackTrace();
        } finally {
            out.close();
            sockfd.close();
        }
    }
}
