import java.io.*;
import java.net.*;
import java.time.*;
import java.time.format.*;

class GreenPass implements Serializable {
    String tessera;
    long scadenza;
    int servizio;
}

public class ClientS {
    public static void main(String[] args) throws IOException {
        if (args.length != 3) {
            System.err.printf("usage: %s <IPaddress> <TesseraSanitaria>\n", ClientS.class.getSimpleName());
            System.exit(1);
        }

        if (args[2].length() != 20) {
            System.err.println("Tessera Sanitaria non valida");
            System.exit(1);
        }

        Socket sockfd;
        ObjectInputStream in;
        ObjectOutputStream out;

        try {
            sockfd = new Socket(args[0], 1026);
            out = new ObjectOutputStream(sockfd.getOutputStream());
            in = new ObjectInputStream(sockfd.getInputStream());
        } catch (IOException e) {
            System.err.println("Error connecting to the server");
            e.printStackTrace();
            return;
        }

        GreenPass greenPass = new GreenPass();
        greenPass.tessera = args[2];
        greenPass.servizio = 0;

        try {
            out.writeObject(greenPass);
            out.flush();
            System.out.println("Richiesta inoltrata");

            greenPass = (GreenPass) in.readObject();

            System.out.println("Tessera Sanitaria: " + greenPass.tessera);
            System.out.println("Scadenza: " + LocalDateTime.ofInstant(Instant.ofEpochSecond(greenPass.scadenza), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

            if (greenPass.scadenza >= System.currentTimeMillis() / 1000) {
                System.out.println("Validita greenPass: VALIDO");
            } else {
                System.out.println("Validita greenPass: NON VALIDO");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("Error reading from the server");
            e.printStackTrace();
        } finally {
            in.close();
            out.close();
            sockfd.close();
        }
    }
}
