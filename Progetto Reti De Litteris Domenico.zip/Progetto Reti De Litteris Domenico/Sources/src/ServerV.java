import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.concurrent.Semaphore;

class GreenPass implements Serializable {
    private static final long serialVersionUID = 1L;
    public String tessera;
    public Date scadenza;
    public int servizio;
}

public class ServerV {
    private static final int SCADENZASEIMESI = 15552000;
    private static final int SCADENZADUEGIORNI = 172800;

    public static void main(String[] args) {
        int list_fd;
		Socket conn_fd;
        ServerSocket serverSocket;
        GreenPass received;
        GreenPass temp;
        Semaphore access = new Semaphore(1);
        RandomAccessFile file;

        try {
            file = new RandomAccessFile("file", "rw");
            serverSocket = new ServerSocket(1025);

            while (true) {
                conn_fd = serverSocket.accept();

                new Thread(() -> {
                    try {
                        if (readObject(conn_fd) != null) {
                            received = (GreenPass) readObject(conn_fd);

                            switch (received.servizio) {
                                case -1:
                                    // caso in cui il servizio richiesto arrivi da centroVaccinale -> inserire nuovo greenPass

                                    // controllo che non esista già un greenPass associato a questa Tessera
                                    int i = 0;
                                    boolean greenPassFound = false;

                                    access.acquire();
                                    file.seek(0);

                                    while (file.getFilePointer() < file.length()) {
                                        temp = readGreenPassFromFile(file);

                                        if (temp.tessera.equals(received.tessera)) {
                                            file.seek(i * GreenPassSize());
                                            writeGreenPassToFile(file, received);
                                            greenPassFound = true;

                                            System.out.println("Tessera Sanitaria: " + received.tessera + " aggiornata");
                                            System.out.println("Scadenza: " + received.scadenza.toString());
                                            System.out.println("--------");
                                            break;
                                        }

                                        i++;
                                    }

                                    access.release();

                                    // nel caso in cui risulti un nuovo greenPass
                                    if (!greenPassFound) {
                                        access.acquire();
                                        file.seek(file.length());
                                        writeGreenPassToFile(file, received);
                                        access.release();

                                        System.out.println("Tessera Sanitaria: " + received.tessera);
                                        System.out.println("Scadenza: " + received.scadenza.toString());
                                        System.out.println("--------");
                                    }

                                    break;

                                case 0:
                                    // richiesta in arrivo da clientS tramite serverG -> restituire greenPass corrispondente alla tessera sanitaria inviata
                                    i = 0;
                                    boolean greenPassSent = false;

                                    access.acquire();
                                    file.seek(0);

                                    while (file.getFilePointer() < file.length()) {
                                        temp = readGreenPassFromFile(file);

                                        if (temp.tessera.equals(received.tessera)) {
                                            access.release();
                                            sendObject(conn_fd, temp);
                                            greenPassSent = true;
                                            break;
                                        }

                                        i++;
                                    }

                                    access.release();

                                    // nel caso in cui non ci sia il greenPass scrivo 0 a serverG
                                    if (!greenPassSent) {
                                        sendObject(conn_fd, 0);
                                    }

                                    break;

                                case 1:
                                    // servizio richiesto da clientT (convalida) tramite serverG
                                    i = 0;

                                    System.out.println("Convalida greenPass in corso");

                                    access.acquire();
                                    file.seek(0);

                                    while (file.getFilePointer() < file.length()) {
                                        temp = readGreenPassFromFile(file);

                                        if (temp.tessera.equals(received.tessera)) {
                                            if (temp.servizio == 3) { // nel caso in cui sia stato aggiunto come greenPass da tampone in precedenza
                                                temp.scadenza = new Date(System.currentTimeMillis() + SCADENZADUEGIORNI * 1000);
                                            } else {
                                                temp.scadenza = new Date(System.currentTimeMillis() + SCADENZASEIMESI * 1000);
                                            }

                                            System.out.println("Green Pass convalidato");
                                            file.seek(i * GreenPassSize());
                                            writeGreenPassToFile(file, temp);
                                            access.release();
                                            break;
                                        }

                                        i++;
                                    }

                                    access.release();

                                    // nel caso non sia nel file dei vaccinati, la tessera sanitaria ottiene il greenPass valido per 2 giorni (ha effettuato un tampone)
                                    if (i == file.length() / GreenPassSize()) {
                                        temp = new GreenPass();
                                        temp.tessera = received.tessera;
                                        temp.scadenza = new Date(System.currentTimeMillis() + SCADENZADUEGIORNI * 1000);
                                        temp.servizio = 3;

                                        System.out.println("Tessera Sanitaria: " + temp.tessera);
                                        System.out.println("Scadenza: " + temp.scadenza.toString());

                                        access.acquire();
                                        file.seek(file.length());
                                        writeGreenPassToFile(file, temp);
                                        access.release();
                                    }

                                    break;

                                case 2:
                                    System.out.println("Invalidamento green pass in corso");
                                    i = 0;

                                    access.acquire();
                                    file.seek(0);

                                    while (file.getFilePointer() < file.length()) {
                                        temp = readGreenPassFromFile(file);

                                        if (temp.tessera.equals(received.tessera)) {
                                            temp.scadenza = new Date(System.currentTimeMillis() - SCADENZADUEGIORNI * 1000);

                                            System.out.println("Green Pass invalidato");
                                            file.seek(i * GreenPassSize());
                                            writeGreenPassToFile(file, temp);
                                            access.release();
                                            break;
                                        }

                                        i++;
                                    }

                                    access.release();

                                    // nel caso non sia presente nei vaccinati, lo inserisco comunque in quanto una volta guarito avrà il greenPass da guarigione da Covid
                                    if (i == file.length() / GreenPassSize()) {
                                        temp = new GreenPass();
                                        temp.tessera = received.tessera;
                                        temp.scadenza = new Date(System.currentTimeMillis() - SCADENZADUEGIORNI * 1000);

                                        System.out.println("Tessera Sanitaria: " + temp.tessera);
                                        System.out.println("Scadenza: " + temp.scadenza.toString());

                                        access.acquire();
                                        file.seek(file.length());
                                        writeGreenPassToFile(file, temp);
                                        access.release();
                                    }

                                    break;
                            }
                        }

                        file.close();
                        conn_fd.close();
                    } catch (IOException | ClassNotFoundException | InterruptedException e) {
                        e.printStackTrace();
                    }
                }).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void sendObject(Socket socket, Object obj) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        oos.writeObject(obj);
        oos.flush();
    }

    private static Object readObject(Socket socket) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        return ois.readObject();
    }

    private static GreenPass readGreenPassFromFile(RandomAccessFile file) throws IOException {
        GreenPass greenPass = new GreenPass();
        greenPass.tessera = file.readUTF();
        greenPass.scadenza = new Date(file.readLong());
        greenPass.servizio = file.readInt();
        return greenPass;
    }

    private static void writeGreenPassToFile(RandomAccessFile file, GreenPass greenPass) throws IOException {
        file.writeUTF(greenPass.tessera);
        file.writeLong(greenPass.scadenza.getTime());
        file.writeInt(greenPass.servizio);
    }

    private static int GreenPassSize() {
        return 21 + 8 + 4; // size of tessera + size of scadenza + size of servizio
    }
}

    
