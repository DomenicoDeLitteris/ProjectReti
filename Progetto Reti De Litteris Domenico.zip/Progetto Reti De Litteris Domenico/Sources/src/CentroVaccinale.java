import java.io.*;
import java.net.*;

class GreenPass implements Serializable {
    String tessera;
    long scadenza;
    int servizio;
}

public class CentroVaccinale {
    private static final int SCADENZASEIMESI = 15552000;

    public static void main(String[] args) throws IOException {
        int listenfd, serverVfd;
		Socket connfd;
        int n;
        ServerSocket servCV;
        Socket serverV;
        GreenPass greenPass;
        int logging = 1;
        int n_client = 0;

        if (args.length != 1) {
            System.err.printf("usage: %s <IPaddress>\n", CentroVaccinale.class.getSimpleName());
            System.exit(1);
        }

        servCV = new ServerSocket(1024);

        for (;;) {
            connfd = servCV.accept();
            n_client++;

            if (logging == 1) {
                System.out.println("Connection accepted");
            }

            new Thread(new ClientHandler(connfd, args[0])).start();
        }
    }

    static class ClientHandler implements Runnable {
        private Socket connfd;
        private String serverVAddress;

        public ClientHandler(Socket connfd, String serverVAddress) {
            this.connfd = connfd;
            this.serverVAddress = serverVAddress;
        }

        @Override
        public void run() {
            try {
                handleClient();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void handleClient() throws IOException {
            BufferedReader in = new BufferedReader(new InputStreamReader(connfd.getInputStream()));
            ObjectOutputStream out = new ObjectOutputStream(connfd.getOutputStream());

            GreenPass greenPass = new GreenPass();

            String tessera = in.readLine();
            greenPass.tessera = tessera;
            if (tessera == null) {
                return;
            }

            if (logging == 1) {
                System.out.println("Received tessera: " + greenPass.tessera);
            }

            greenPass.scadenza = System.currentTimeMillis() / 1000 + SCADENZASEIMESI;
            greenPass.servizio = -1;

            serverV = new Socket(serverVAddress, 1025);
            out = new ObjectOutputStream(serverV.getOutputStream());
            out.writeObject(greenPass);
            out.flush();

            if (logging == 1) {
                System.out.println("Green Pass consegnato a server V");
            }

            connfd.close();
            serverV.close();
        }
    }
}
